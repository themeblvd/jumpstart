<nav class="woocommerce-pagination">
	<?php themeblvd_pagination(); ?>
</nav>