When compiling Bootstrap, make sure uncheck “Glyphicons”

And only keep following files:
/css/bootstrap.css
/css/bootstrap.min.css
/js/bootstrap.js
/js/bootstrap.min.js
