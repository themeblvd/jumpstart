<?php
/**
 * The default template for displaying content in small post list.
 *
 * @author      Jason Bobich
 * @copyright   2009-2017 Theme Blvd
 * @link        http://themeblvd.com
 * @package     Jump_Start
 */
 // @TODO This feature hasn't been built yet.
?>
