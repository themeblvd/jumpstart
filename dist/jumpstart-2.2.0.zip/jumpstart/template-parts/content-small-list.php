<?php
/**
 * The default template for displaying content in small post list.
 *
 * @author     Jason Bobich <info@themeblvd.com>
 * @copyright  2009-2017 Theme Blvd
 * @package    Jump_Start
 * @subpackage Theme_Blvd
 * @since      Theme_Blvd 2.0.0
 */
 // @TODO This feature hasn't been built yet.
?>
