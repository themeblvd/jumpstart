<?php
/**
 * The default template for displaying content in small post list.
 */
 // @TODO This feature hasn't been built yet.
?>
