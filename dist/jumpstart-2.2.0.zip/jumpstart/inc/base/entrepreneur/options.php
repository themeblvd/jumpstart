<?php
/**
 * Theme Base: Entrepeneur, Options
 *
 * @author    Jason Bobich <info@themeblvd.com>
 * @copyright 2009-2017 Theme Blvd
 * @package   Jump_Start
 * @since     Jump_Start 2.0.0
 */

/**
 * Add theme options to framework.
 *
 * @since Jump_Start 2.0.0
 */
function jumpstart_ent_options() {

	// Background support
	add_theme_support( 'custom-background', array(
		'default-color' => 'f8f8f8',
		'default-image' => '',
	));

	$bg_types = array();

	if ( function_exists( 'themeblvd_get_bg_types' ) ) {

		$bg_types = themeblvd_get_bg_types( 'section' );

	}

	/**
	 * Filters the options added by the Entrepeneur
	 * base to the theme options page.
	 *
	 * @since Jump_Start 2.0.0
	 *
	 * @param array Options added.
	 */
	$options = apply_filters( 'jumpstart_ent_options', array(
		'general' => array(
			'sub_group_start_1' => array(
				'id'      => 'sub_group_start_1',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide-toggle',
			),
			'layout_style' => array(
				'id'      => 'layout_style',
				'name'    => __( 'Site Layout Style', 'jumpstart' ),
				'desc'    => __( 'Select whether you\'d like the layout of the theme to be boxed or not.', 'jumpstart' ),
				'std'     => 'stretch',
				'type'    => 'select',
				'options' => array(
					'stretch' => __( 'Stretch', 'jumpstart' ),
					'boxed'   => __( 'Boxed', 'jumpstart' ),
				),
				'class'   => 'trigger',
			),
			'layout_shadow_size' => array(
				'id'      => 'layout_shadow_size',
				'name'    => __( 'Layout Shadow Size', 'jumpstart' ),
				'desc'    => __( 'Select the size of the shadow around the boxed layout. Set to 0px for no shadow.', 'jumpstart' ),
				'std'     => '5px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '20',
				),
				'class'   => 'receiver receiver-boxed',
			),
			'layout_shadow_opacity' => array(
				'id'      => 'layout_shadow_opacity',
				'name'    => __( 'Layout Shadow Strength', 'jumpstart' ),
				// translators: 1: link to Backgrounds admin screen
				'desc'    => sprintf( __( 'Select the opacity of the shadow for the boxed layout. The darker %s, the closer to 100%% you want to go.', 'jumpstart' ), '<a href="' . esc_url( admin_url( 'customize.php?autofocus[control]=background_image' ) ) . '" target="_blank">' . __( 'your background', 'jumpstart' ) . '</a>' ),
				'std'     => '0.3',
				'type'    => 'select',
				'options' => array(
					'0.05' => '5%',
					'0.1'  => '10%',
					'0.15' => '15%',
					'0.2'  => '20%',
					'0.25' => '25%',
					'0.3'  => '30%',
					'0.35' => '35%',
					'0.4'  => '40%',
					'0.45' => '45%',
					'0.5'  => '50%',
					'0.55' => '55%',
					'0.6'  => '60%',
					'0.65' => '65%',
					'0.7'  => '70%',
					'0.75' => '75%',
					'0.8'  => '80%',
					'0.85' => '85%',
					'0.9'  => '90%',
					'0.95' => '95%',
					'1'    => '100%',
				),
				'class'   => 'receiver  receiver-boxed',
			),
			'layout_border_width' => array(
				'id'      => 'layout_border_width',
				'name'    => __( 'Layout Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the boxed layout. Set to 0px for no border.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '20',
				),
				'class'   => 'receiver receiver-boxed',
			),
			'layout_border_color' => array(
				'id'      => 'layout_border_color',
				'name'    => __( 'Layout Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the border around the boxed layout.', 'jumpstart' ),
				'std'     => '#cccccc',
				'type'    => 'color',
				'class'   => 'receiver receiver-boxed',
			),
			'sub_group_start_2' => array(
				'id'      => 'sub_group_start_2',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide receiver receiver-stretch',
			),
			'apply_content_border' => array(
				'id'      => 'apply_content_border',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Content Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply border around content areas.', 'jumpstart' ),
				'std'     => 0,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'content_border_color' => array(
				'id'      => 'content_border_color',
				'name'    => __( 'Content Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the border around content areas.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'content_border_width' => array(
				'id'      => 'content_border_width',
				'name'    => __( 'Bottom Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the border around content areas.', 'jumpstart' ),
				'std'     => '1px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_2' => array(
				'id'      => 'sub_group_end_2',
				'type'    => 'subgroup_end',
			),
			'sub_group_end_1' => array(
				'id'      => 'sub_group_end_1',
				'type'    => 'subgroup_end',
			),
		),
		'header_info' => array(
			'header_info' => array(
				'name'    => null,
				'desc'    => __( 'Note: With the Entrepeneur theme base, for the header info top bar to show, you must enter text at Theme Options > Layout > Header > Header Text. Without this, other header info elements like social icons and searchform, will be displayed next to the main menu instead.', 'jumpstart' ),
				'id'      => 'header_info',
				'type'    => 'info',
			),
			'top_bg_color' => array(
				'id'      => 'top_bg_color',
				'name'    => __( 'Top Bar Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for the bar that runs across the top of the header.', 'jumpstart' ),
				'std'     => '#ffffff',
				'type'    => 'color',
			),
			'top_bg_color_opacity' => array(
				'id'      => 'top_bg_color_opacity',
				'name'    => __( 'Top Bar Background Color Opacity', 'jumpstart' ),
				'desc'    => __( 'Select the opacity of the above background color. Selecting "100%" means that the background color is not transparent, at all.', 'jumpstart' ),
				'std'     => '1',
				'type'    => 'select',
				'options' => array(
					'0.05' => '5%',
					'0.1'  => '10%',
					'0.15' => '15%',
					'0.2'  => '20%',
					'0.25' => '25%',
					'0.3'  => '30%',
					'0.35' => '35%',
					'0.4'  => '40%',
					'0.45' => '45%',
					'0.5'  => '50%',
					'0.55' => '55%',
					'0.6'  => '60%',
					'0.65' => '65%',
					'0.7'  => '70%',
					'0.75' => '75%',
					'0.8'  => '80%',
					'0.85' => '85%',
					'0.9'  => '90%',
					'0.95' => '95%',
					'1'    => '100%',
				),
			),
			'top_text_color' => array(
				'id'      => 'top_text_color',
				'name'    => __( 'Top Bar Text Color', 'jumpstart' ),
				'desc'    => __( 'If you\'re using a dark background color, select to show light text, and vice versa.', 'jumpstart' ),
				'std'     => 'dark',
				'type'    => 'select',
				'options' => array(
					'dark'  => __( 'Dark Text', 'jumpstart' ),
					'light' => __( 'Light Text', 'jumpstart' ),
				),
			),
			'sub_group_start_3' => array(
				'id'      => 'sub_group_start_3',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide',
			),
			'top_apply_border_bottom' => array(
				'id'      => 'top_apply_border_bottom',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Bottom Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply bottom border to the top bar of the header.', 'jumpstart' ),
				'std'     => 1,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'top_border_bottom_color' => array(
				'id'      => 'top_border_bottom_color',
				'name'    => __( 'Bottom Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the bottom border.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'top_border_bottom_width' => array(
				'id'      => 'top_border_bottom_width',
				'name'    => __( 'Bottom Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the bottom border.', 'jumpstart' ),
				'std'     => '1px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_3' => array(
				'id'      => 'sub_group_end_3',
				'type'    => 'subgroup_end',
			),
			'top_mini' => array(
				'id'      => 'top_mini',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Mini Display', 'jumpstart' ) . '</strong>: ' . __( 'Display top bar a bit smaller and more condensed.', 'jumpstart' ),
				'std'     => 1,
				'type'    => 'checkbox',
			),
		),
		'header' => array(
			'header_height' => array(
				'id'      => 'header_height',
				'name'    => __( 'Header Height', 'jumpstart' ),
				'desc'    => __( 'Apply a fixed height to the header. Keep in mind that your header logo image will always be displayed to match the height of your header, minus 20px.', 'jumpstart' ),
				'type'    => 'slide',
				'std'     => '70px',
				'options' => array(
					'units' => 'px',
					'min'   => '45',
					'max'   => '150',
					'step'  => '1',
				),
			),
			'sub_group_start_4' => array(
				'id'      => 'sub_group_start_4',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide-toggle',
			),
			'header_bg_type' => array(
				'id'      => 'header_bg_type',
				'name'    => __( 'Apply Header Background', 'jumpstart' ),
				'desc'    => __( 'Select if you\'d like to apply a custom background and how you want to control it.', 'jumpstart' ),
				'std'     => 'color',
				'type'    => 'select',
				'options' => $bg_types,
				'class'   => 'trigger',
			),
			'header_bg_color' => array(
				'id'      => 'header_bg_color',
				'name'    => __( 'Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color.', 'jumpstart' ),
				'std'     => '#ffffff',
				'type'    => 'color',
				'class'   => 'hide receiver receiver-color receiver-texture receiver-image receiver-slideshow',
			),
			'header_bg_color_opacity' => array(
				'id'      => 'header_bg_color_opacity',
				'name'    => __( 'Background Color Opacity', 'jumpstart' ),
				'desc'    => __( 'Select the opacity of the background color. Selecting "100%" means that the background color is not transparent, at all.', 'jumpstart' ),
				'std'     => '1',
				'type'    => 'select',
				'options' => array(
					'0.05' => '5%',
					'0.1'  => '10%',
					'0.15' => '15%',
					'0.2'  => '20%',
					'0.25' => '25%',
					'0.3'  => '30%',
					'0.35' => '35%',
					'0.4'  => '40%',
					'0.45' => '45%',
					'0.5'  => '50%',
					'0.55' => '55%',
					'0.6'  => '60%',
					'0.65' => '65%',
					'0.7'  => '70%',
					'0.75' => '75%',
					'0.8'  => '80%',
					'0.85' => '85%',
					'0.9'  => '90%',
					'0.95' => '95%',
					'1'    => '100%',
				),
				'class'   => 'hide receiver receiver-color receiver-texture',
			),
			'header_bg_texture' => array(
				'id'      => 'header_bg_texture',
				'name'    => __( 'Background Texture', 'jumpstart' ),
				'desc'    => __( 'Select a background texture.', 'jumpstart' ),
				'type'    => 'select',
				'select'  => 'textures',
				'class'   => 'hide receiver receiver-texture',
			),
			'header_apply_bg_texture_parallax' => array(
				'id'      => 'header_apply_bg_texture_parallax',
				'name'    => null,
				'desc'    => __( 'Apply parallax scroll effect to background texture.', 'jumpstart' ),
				'type'    => 'checkbox',
				'class'   => 'hide receiver receiver-texture',
			),
			'sub_group_start_5' => array(
				'id'      => 'sub_group_start_5',
				'type'    => 'subgroup_start',
				'class'   => 'select-parallax hide receiver receiver-image',
			),
			'header_bg_image' => array(
				'id'      => 'header_bg_image',
				'name'    => __( 'Background Image', 'jumpstart' ),
				'desc'    => __( 'Select a background image.', 'jumpstart' ),
				'type'    => 'background',
				'color'    => false,
				'parallax' => true,
			),
			'sub_group_end_5' => array(
				'id'      => 'sub_group_end_5',
				'type'    => 'subgroup_end',
			),
			'header_bg_video' => array(
				'id'      => 'header_bg_video',
				'name'    => __( 'Background Video', 'jumpstart' ),
				'desc'    => __( 'You can upload a web-video file (mp4, webm, ogv), or input a URL to a video page on YouTube or Vimeo. Your fallback image will display on mobile devices.', 'jumpstart' ) . '<br><br>' . __( 'Examples:', 'jumpstart' ) . '<br>https://vimeo.com/79048048<br>http://www.youtube.com/watch?v=5guMumPFBag',
				'type'    => 'background_video',
				'class'   => 'hide receiver receiver-video',
			),
			'sub_group_start_6' => array(
				'id'      => 'sub_group_start_6',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide hide receiver receiver-image receiver-slideshow',
			),
			'header_apply_bg_shade' => array(
				'id'      => 'header_apply_bg_shade',
				'name'    => null,
				'desc'    => __( 'Shade background with transparent color.', 'jumpstart' ),
				'std'     => 0,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'header_bg_shade_color' => array(
				'id'      => 'header_bg_shade_color',
				'name'    => __( 'Shade Color', 'jumpstart' ),
				'desc'    => __( 'Select the color you want overlaid on your background.', 'jumpstart' ),
				'std'     => '#000000',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'header_bg_shade_opacity' => array(
				'id'      => 'header_bg_shade_opacity',
				'name'    => __( 'Shade Opacity', 'jumpstart' ),
				'desc'    => __( 'Select the opacity of the shade color overlaid on your background.', 'jumpstart' ),
				'std'     => '0.5',
				'type'    => 'select',
				'options' => array(
					'0.05' => '5%',
					'0.1'  => '10%',
					'0.15' => '15%',
					'0.2'  => '20%',
					'0.25' => '25%',
					'0.3'  => '30%',
					'0.35' => '35%',
					'0.4'  => '40%',
					'0.45' => '45%',
					'0.5'  => '50%',
					'0.55' => '55%',
					'0.6'  => '60%',
					'0.65' => '65%',
					'0.7'  => '70%',
					'0.75' => '75%',
					'0.8'  => '80%',
					'0.85' => '85%',
					'0.9'  => '90%',
					'0.95' => '95%',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_6' => array(
				'id'      => 'sub_group_end_6',
				'type'    => 'subgroup_end',
			),
			'sub_group_start_7' => array(
				'id'      => 'sub_group_start_7',
				'type'    => 'subgroup_start',
				'class'   => 'section-bg-slideshow hide receiver receiver-slideshow',
			),
			'header_bg_slideshow' => array(
				'id'      => 'header_bg_slideshow',
				'name'    => __( 'Slideshow Images', 'jumpstart' ),
				'desc'    => null,
				'type'    => 'slider',
			),
			'header_bg_slideshow_crop' => array(
				'name'    => __( 'Slideshow Crop Size', 'jumpstart' ),
				'desc'    => __( 'Select the crop size to be used for the background slideshow images. Remember that the background images will be stretched to cover the area.', 'jumpstart' ),
				'id'      => 'header_bg_slideshow_crop',
				'std'     => 'full',
				'type'    => 'select',
				'select'  => 'crop',
			),
			'header_apply_bg_slideshow_parallax' => array(
				'id'      => 'header_apply_bg_slideshow_parallax',
				'name'    => null,
				'desc'    => __( 'Apply parallax scroll effect to background slideshow.', 'jumpstart' ),
				'type'    => 'checkbox',
			),
			'sub_group_end_7' => array(
				'id'      => 'sub_group_end_7',
				'type'    => 'subgroup_end',
			),
			'sub_group_end_4' => array(
				'id'      => 'sub_group_end_4',
				'type'    => 'subgroup_end',
			),
			'sub_group_start_8' => array(
				'id'      => 'sub_group_start_8',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide',
			),
			'header_text_color' => array(
				'id'      => 'header_text_color',
				'name'    => __( 'Text Color', 'jumpstart' ),
				'desc'    => __( 'If you\'re using a dark background color, select to show light text, and vice versa.', 'jumpstart' ),
				'std'     => 'dark',
				'type'    => 'select',
				'options' => array(
					'dark'  => __( 'Dark Text', 'jumpstart' ),
					'light' => __( 'Light Text', 'jumpstart' ),
				),
			),
			'header_apply_border_top' => array(
				'id'      => 'header_apply_border_top',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Top Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply top border to header.', 'jumpstart' ),
				'std'     => 0,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'header_border_top_color' => array(
				'id'      => 'header_border_top_color',
				'name'    => __( 'Top Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the top border.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'header_border_top_width' => array(
				'id'      => 'header_border_top_width',
				'name'    => __( 'Top Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the top border.', 'jumpstart' ),
				'std'     => '5px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_8' => array(
				'id'      => 'sub_group_end_8',
				'type'    => 'subgroup_end',
			),
			'sub_group_start_9' => array(
				'id'      => 'sub_group_start_9',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide',
			),
			'header_apply_border_bottom' => array(
				'id'      => 'header_apply_border_bottom',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Bottom Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply bottom border to header.', 'jumpstart' ),
				'std'     => 1,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'header_border_bottom_color' => array(
				'id'      => 'header_border_bottom_color',
				'name'    => __( 'Bottom Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the bottom border.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'header_border_bottom_width' => array(
				'id'      => 'header_border_bottom_width',
				'name'    => __( 'Bottom Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the bottom border.', 'jumpstart' ),
				'std'     => '1px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_9' => array(
				'id'      => 'sub_group_end_9',
				'type'    => 'subgroup_end',
			),
		),
		'header_mobile' => array(
			'header_mobile_info' => array(
				'id'      => 'header_mobile_info',
				'desc'    => __( 'These styles are applied to your header across most mobile devices and portrait tablets.', 'jumpstart' ),
				'type'    => 'info',
			),
			'header_mobile_bg_color' => array(
				'id'      => 'header_mobile_bg_color',
				'name'    => __( 'Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for the mobile header.', 'jumpstart' ),
				'std'     => '#333333',
				'type'    => 'color',
			),
			'header_mobile_icon_color' => array(
				'id'       => 'header_mobile_icon_color',
				'name'     => __( 'Icon Color', 'jumpstart' ),
				'desc'     => __( 'Select a color for the navigational icons in the mobile header.', 'jumpstart' ),
				'std'      => '#ffffff',
				'type'     => 'color',
			),
			'header_mobile_height' => array(
				'id'       => 'header_mobile_height',
				'name'     => __( 'Height', 'jumpstart' ),
				'desc'     => __( 'Set the height of your mobile header in pixels. This number should be higher than the height of your mobile logo image at <em>Layout > Mobile Header</em>.', 'jumpstart' ),
				'std'      => '64px',
				'type'     => 'slide',
				'options'  => array(
					'min'   => '40',
					'max'   => '150',
					'step'  => '1',
					'units' => 'px',
				)
 			),
		),
		'menu' => array(
			'menu_text_shadow' => array(
				'id'      => 'menu_text_shadow',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Text Shadow', 'jumpstart' ) . '</strong>: ' . __( 'Apply shadow to the text of the main menu.', 'jumpstart' ) . ' &mdash; <em>' . __( 'Note: This works better with a darker colored header.', 'jumpstart' ) . '</em>',
				'std'     => 0,
				'type'    => 'checkbox',
			),
			'menu_highlight' => array(
				'id'      => 'menu_highlight',
				'name'    => __( 'Highlight Color', 'jumpstart' ),
				'desc'    => __( 'Select a color to be used as a sublte highlight to the main menu.', 'jumpstart' ),
				'std'     => '#fec427',
				'type'    => 'color',
			),
			'menu_highlight_trans' => array(
				'id'      => 'menu_highlight_trans',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Transparent Header', 'jumpstart' ) . ':</strong> ' . __( 'Also apply menu highlight color top-level menu items, when using transparent header.', 'jumpstart' ),
				'std'     => '0',
				'type'    => 'checkbox',
			),
			'menu_sub_bg_color' => array(
				'id'      => 'menu_sub_bg_color',
				'name'    => __( 'Dropdown Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for the main menu\'s drop down menus.', 'jumpstart' ),
				'std'     => '#ffffff',
				'type'    => 'color',
			),
			'menu_sub_bg_color_brightness' => array(
				'id'      => 'menu_sub_bg_color_brightness',
				'name'    => __( 'Dropdown Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'std'     => 'light',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
			),
		),
		'menu_mobile' => array(
			'menu_mobile_bg_color' => array(
				'id'      => 'menu_mobile_bg_color',
				'name'    => __( 'Mobile Menu Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for the mobile menu side panel.', 'jumpstart' ),
				'std'     => '#222222',
				'type'    => 'color',
			),
			'menu_mobile_bg_color_brightness' => array(
				'id'      => 'menu_mobile_bg_color_brightness',
				'name'    => __( 'Mobile Menu Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'std'     => 'dark',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
			),
		),
		'side_panel' => array(
			'side_info' => array(
				'id'      => 'side_info',
				// translators: 1: link to Menus admin screen
				'desc'    => sprintf( __( 'These options apply to the side panel that shows on desktops when you assign a menu to the "Primary Side Navigation" or "Secondary Side Navigation" locations at %s.', 'jumpstart' ), '<a href="nav-menus.php" target="_blank">' . __( 'Appearance > Menus', 'jumpstart' ) . '</a>' ),
				'type'    => 'info',
			),
			'side_bg_color' => array(
				'id'      => 'side_bg_color',
				'name'    => __( 'Side Panel Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for the desktop side panel.', 'jumpstart' ),
				'std'     => '#222222',
				'type'    => 'color',
			),
			'side_bg_color_brightness' => array(
				'id'      => 'side_bg_color_brightness',
				'name'    => __( 'Side Panel Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'std'     => 'dark',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
			),
		),
		'footer' => array(
			'sub_group_start_10' => array(
				'id'      => 'sub_group_start_10',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide-toggle',
			),
			'footer_bg_type' => array(
				'id'      => 'footer_bg_type',
				'name'    => __( 'Footer Background', 'jumpstart' ),
				// translators: 1: location of where to setup Template Sync feature on Theme Options screen
				'desc'    => __( 'Select if you\'d like to apply a custom background color to the footer.', 'jumpstart' ) . '<br><br>' . sprintf( __( 'Note: To setup a more complex designed footer, go to %s and use the "Template Sync" feature.', 'jumpstart' ), '<em>' . __( 'Layout > Footer', 'jumpstart' ) . '</em>' ),
				'std'     => 'color',
				'type'    => 'select',
				'options' => array(
					'none'    => __( 'None', 'jumpstart' ),
					'color'   => __( 'Custom color', 'jumpstart' ),
					'texture' => __( 'Custom color + texture', 'jumpstart' ),
				),
				'class'   => 'trigger',
			),
			'footer_bg_texture' => array(
				'id'      => 'footer_bg_texture',
				'name'    => __( 'Background Texture', 'jumpstart' ),
				'desc'    => __( 'Select a background texture.', 'jumpstart' ),
				'type'    => 'select',
				'select'  => 'textures',
				'class'   => 'hide receiver receiver-texture',
			),
			'footer_bg_color' => array(
				'id'      => 'footer_bg_color',
				'name'    => __( 'Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for the footer.', 'jumpstart' ),
				'std'     => '#ffffff',
				'type'    => 'color',
				'class'   => 'hide receiver receiver-color receiver-texture',
			),
			'footer_bg_color_brightness' => array(
				'id'      => 'footer_bg_color_brightness',
				'name'    => __( 'Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'std'     => 'light',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
				'class'   => 'hide receiver receiver-color receiver-texture',
			),
			'footer_bg_color_opacity' => array(
				'id'      => 'footer_bg_color_opacity',
				'name'    => __( 'Background Color Opacity', 'jumpstart' ),
				'desc'    => __( 'Select the opacity of the background color you chose.', 'jumpstart' ),
				'std'     => '1',
				'type'    => 'select',
				'options' => array(
					'0.05' => '5%',
					'0.1'  => '10%',
					'0.15' => '15%',
					'0.2'  => '20%',
					'0.25' => '25%',
					'0.3'  => '30%',
					'0.35' => '35%',
					'0.4'  => '40%',
					'0.45' => '45%',
					'0.5'  => '50%',
					'0.55' => '55%',
					'0.6'  => '60%',
					'0.65' => '65%',
					'0.7'  => '70%',
					'0.75' => '75%',
					'0.8'  => '80%',
					'0.85' => '85%',
					'0.9'  => '90%',
					'0.95' => '95%',
					'1'    => '100%',
				),
				'class'   => 'hide receiver receiver-color receiver-texture',
			),
			'sub_group_end_10' => array(
				'id'      => 'sub_group_end_10',
				'type'    => 'subgroup_end',
			),
			'sub_group_start_11' => array(
				'id'      => 'sub_group_start_11',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide',
			),
			'footer_apply_border_top' => array(
				'id'      => 'footer_apply_border_top',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Top Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply top border to footer.', 'jumpstart' ),
				'std'     => 1,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'footer_border_top_color' => array(
				'id'      => 'footer_border_top_color',
				'name'    => __( 'Top Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the top border.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'footer_border_top_width' => array(
				'id'      => 'footer_border_top_width',
				'name'    => __( 'Top Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the top border.', 'jumpstart' ),
				'std'     => '1px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_11' => array(
				'id'      => 'sub_group_end_11',
				'type'    => 'subgroup_end',
			),
			'sub_group_start_12' => array(
				'id'      => 'sub_group_start_12',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide',
			),
			'footer_apply_border_bottom' => array(
				'id'      => 'footer_apply_border_bottom',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Bottom Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply bottom border to footer.', 'jumpstart' ),
				'std'     => 0,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'footer_border_bottom_color' => array(
				'id'      => 'footer_border_bottom_color',
				'name'    => __( 'Bottom Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the bottom border.', 'jumpstart' ),
				'std'     => '#181818',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'footer_border_bottom_width' => array(
				'id'      => 'footer_border_bottom_width',
				'name'    => __( 'Bottom Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the bottom border.', 'jumpstart' ),
				'std'     => '1px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_12' => array(
				'id'      => 'sub_group_end_12',
				'type'    => 'subgroup_end',
			),
		),
		'typo' => array(
			'font_body' => array(
				'id'      => 'font_body',
				'name'    => __( 'Primary Font', 'jumpstart' ),
				'desc'    => __( 'This applies to most of the text on your site.', 'jumpstart' ),
				'std'     => array(
					'size'   => '16px',
					'face'   => 'google',
					'weight' => '300',
					'color'  => '',
					'google' => 'Raleway:300',
					'style'  => 'normal',
				),
				'atts'    => array( 'size', 'face', 'style', 'weight' ),
				'type'    => 'typography',
			),
			'font_header' => array(
				'id'      => 'font_header',
				'name'    => __( 'Header Font', 'jumpstart' ),
				'desc'    => __( 'This applies to all of the primary headers throughout your site (h1, h2, h3, h4, h5, h6). This would include header tags used in redundant areas like widgets and the content of posts and pages.', 'jumpstart' ),
				'std'     => array(
					'size'   => '',
					'face'   => 'google',
					'weight' => '400',
					'color'  => '',
					'google' => 'Montserrat:400',
					'style'  => 'normal',
				),
				'atts'    => array( 'face', 'style', 'weight' ),
				'type'    => 'typography',
			),
			'font_quote' => array(
				'id'      => 'font_quote',
				'name'    => __( 'Quote Font', 'jumpstart' ),
				'desc'    => __( 'This applies to quoted text in blockquote tags.', 'jumpstart' ),
				'std'     => array(
					'size'   => '',
					'face'   => 'google',
					'weight' => '400',
					'color'  => '',
					'google' => 'Libre Baskerville:400italic',
					'style'  => 'italic',
				),
				'atts'    => array( 'face', 'style', 'weight' ),
				'type'    => 'typography',
			),
			'font_quote_sp' => array(
				'id'      => 'font_quote_sp',
				'name'    => __( 'Quote Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			),
			'font_meta' => array(
				'id'      => 'font_meta',
				'name'    => __( 'Meta Info Font', 'jumpstart' ),
				'desc'    => __( 'This applies to meta info like the "Posted" date below a post title, for example.', 'jumpstart' ),
				'std'     => array(
					'size'   => '',
					'face'   => 'google',
					'weight' => '400',
					'color'  => '',
					'google' => 'Montserrat:400',
					'style'  => 'uppercase',
				),
				'atts'    => array( 'face', 'style', 'weight' ),
				'type'    => 'typography',
			),
			'font_meta_sp' => array(
				'id'      => 'font_meta_sp',
				'name'    => __( 'Meta Info Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			),
			'font_epic' => array(
				'id'      => 'font_epic',
				'name'    => __( 'Featured Image Title Font', 'jumpstart' ),
				'desc'    => __( 'This applies when displaying a title on top of featured images.', 'jumpstart' ),
				'std'     => array(
					'size'   => '50px',
					'face'   => 'google',
					'weight' => '700',
					'color'  => '',
					'google' => 'Montserrat:700',
					'style'  => 'uppercase',
				),
				'atts'    => array( 'face', 'style', 'weight', 'size' ),
				'sizes'   => array( '25', '26', '150' ),
				'type'    => 'typography',
			),
			'font_epic_sp' => array(
				'id'      => 'font_epic_sp',
				'name'    => __( 'Featured Image Title Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '3px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			),
			'font_menu' => array(
				'id'      => 'font_menu',
				'name'    => __( 'Main Menu Font', 'jumpstart' ),
				'desc'    => __( 'This font applies to the top level items of the main menu.', 'jumpstart' ),
				'std'     => array(
					'size'   => '13px',
					'face'   => 'google',
					'weight' => '300',
					'color'  => '#555555',
					'google' => 'Raleway:300',
					'style'  => 'normal',
				),
				'atts'    => array( 'size', 'face', 'style', 'weight' ),
				'sizes'   => array( '10', '11', '12', '13', '14', '15', '16', '17', '18' ),
				'type'    => 'typography',
			),
			'font_menu_sp' => array(
				'id'      => 'font_menu_sp',
				'name'    => __( 'Main Menu Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			),
			'link_color' => array(
				'id'      => 'link_color',
				'name'    => __( 'Link Color', 'jumpstart' ),
				'desc'    => __( 'Choose the color you\'d like applied to links.', 'jumpstart' ),
				'std'     => '#f9bc18',
				'type'    => 'color',
			),
			'link_hover_color' => array(
				'id'      => 'link_hover_color',
				'name'    => __( 'Link Hover Color', 'jumpstart' ),
				'desc'    => __( 'Choose the color you\'d like applied to links when they are hovered over.', 'jumpstart' ),
				'std'     => '#f9d718',
				'type'    => 'color',
			),
			'footer_link_color' => array(
				'id'      => 'footer_link_color',
				'name'    => __( 'Footer Link Color', 'jumpstart' ),
				'desc'    => __( 'Choose the color you\'d like applied to links in the footer.', 'jumpstart' ),
				'std'     => '#f9bc18',
				'type'    => 'color',
			),
			'footer_link_hover_color' => array(
				'id'      => 'footer_link_hover_color',
				'name'    => __( 'Footer Link Hover Color', 'jumpstart' ),
				'desc'    => __( 'Choose the color you\'d like applied to links in the footer when they are hovered over.', 'jumpstart' ),
				'std'     => '#f9d718',
				'type'    => 'color',
			),
		),
		'buttons' => array(
			'btn_default' => array(
				'id'      => 'btn_default',
				'name'    => __( 'Default Buttons', 'jumpstart' ),
				'desc'    => __( 'Configure what a default button looks like.', 'jumpstart' ),
				'std'     => array(
					'bg'             => '#333333',
					'bg_hover'       => '#222222',
					'border'         => '#000000',
					'text'           => '#ffffff',
					'text_hover'     => '#ffffff',
					'include_bg'     => 1,
					'include_border' => 0,
				),
				'type'    => 'button',
			),
			'btn_primary' => array(
				'id'      => 'btn_primary',
				'name'    => __( 'Primary Buttons', 'jumpstart' ),
				'desc'    => __( 'Configure what a primary button looks like.', 'jumpstart' ),
				'std'     => array(
					'bg'             => '#333333',
					'bg_hover'       => '#222222',
					'border'         => '#000000',
					'text'           => '#ffffff',
					'text_hover'     => '#ffffff',
					'include_bg'     => 1,
					'include_border' => 0,
				),
				'type'    => 'button',
			),
			'btn_border' => array(
				'id'      => 'btn_border',
				'name'    => __( 'General Button Border Width', 'jumpstart' ),
				'desc'    => __( 'If your buttons are set to include a border, select a width in pixels for those borders.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
				),
			),
			'btn_corners' => array(
				'id'      => 'btn_corners',
				'name'    => __( 'General Button Corners', 'jumpstart' ),
				'desc'    => __( 'Select the border radius of button corners.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '50',
				),
			),
		),
		'widgets' => array(
			'sub_group_start_13' => array(
				'id'      => 'sub_group_start_13',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide-toggle',
			),
			'widget_style' => array(
				'id'      => 'widget_style',
				'name'    => __( 'Widget Style', 'jumpstart' ),
				'desc'    => __( 'Select how you want to style your widgets.', 'jumpstart' ) . ' <a href="http://getbootstrap.com/components/#panels" target="_blank">' . __( 'What\'s a Bootstrap panel?', 'jumpstart' ) . '</a>',
				'std'     => 'standard',
				'type'    => 'select',
				'options' => array(
					'standard' => __( 'Standard', 'jumpstart' ),
					'panel'    => __( 'Bootstrap Panel', 'jumpstart' ),
				),
				'class'   => 'trigger',
			),
			'sub_group_start_14' => array(
				'id'      => 'sub_group_start_14',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide-toggle hide receiver receiver-panel',
			),
			'widget_panel_style' => array(
				'name'    => __( 'Panel Style', 'jumpstart' ),
				'desc'    => __( 'Select a style for the Bootstrap panel. You can use a preset style, or setup custom colors.', 'jumpstart' ),
				'id'      => 'widget_panel_style',
				'std'     => 'default',
				'type'    => 'select',
				'options' => array(
					'custom'  => __( 'Custom Style', 'jumpstart' ),
					'default' => __( 'Bootstrap: Default', 'jumpstart' ),
					'primary' => __( 'Bootstrap: Primary', 'jumpstart' ),
					'info'    => __( 'Bootstrap: Info (blue)', 'jumpstart' ),
					'warning' => __( 'Bootstrap: Warning (yellow)', 'jumpstart' ),
					'danger'  => __( 'Bootstrap: Danger (red)', 'jumpstart' ),

				),
				'class'   => 'trigger',
			),
			'widget_panel_title_bg_color' => array(
				'id'      => 'widget_panel_title_bg_color',
				'name'    => __( 'Panel Title Background', 'jumpstart' ),
				'desc'    => __( 'Select two colors to create a background gradient for widget titles. For a solid color, simply select the same color twice.', 'jumpstart' ),
				'std'     => array(
					'start' => '#f5f5f5',
					'end'   => '#e8e8e8',
				),
				'type'    => 'gradient',
				'class'   => 'hide receiver receiver-custom',
			),
			'widget_panel_border_color' => array(
				'id'      => 'widget_panel_border_color',
				'name'    => __( 'Panel Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the border.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver receiver-custom',
			),
			'sub_group_end_14' => array(
				'id'      => 'sub_group_end_14',
				'type'    => 'subgroup_end',
			),
			'widget_bg_color' => array(
				'id'      => 'widget_bg_color',
				'name'    => __( 'Widget Background Color', 'jumpstart' ),
				'desc'    => __( 'Select a background color for widgets.', 'jumpstart' ),
				'std'     => '#ffffff',
				'type'    => 'color',
				'class'   => 'hide receiver receiver-standard receiver-panel',
			),
			'widget_bg_brightness' => array(
				'name'    => __( 'Widget Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'id'      => 'widget_bg_brightness',
				'std'     => 'light',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
				'class'   => 'hide receiver receiver-standard receiver-panel',
			),
			'widget_bg_color_opacity' => array(
				'id'      => 'widget_bg_color_opacity',
				'name'    => __( 'Widget Background Color Opacity', 'jumpstart' ),
				'desc'    => __( 'Select the opacity of the background color you chose.', 'jumpstart' ),
				'std'     => '1',
				'type'    => 'select',
				'options' => array(
					'0.05' => '5%',
					'0.1'  => '10%',
					'0.15' => '15%',
					'0.2'  => '20%',
					'0.25' => '25%',
					'0.3'  => '30%',
					'0.35' => '35%',
					'0.4'  => '40%',
					'0.45' => '45%',
					'0.5'  => '50%',
					'0.55' => '55%',
					'0.6'  => '60%',
					'0.65' => '65%',
					'0.7'  => '70%',
					'0.75' => '75%',
					'0.8'  => '80%',
					'0.85' => '85%',
					'0.9'  => '90%',
					'0.95' => '95%',
					'1'    => '100%',
				),
				'class'   => 'hide receiver receiver-standard receiver-panel',
			),
			'widget_title_color' => array(
				'id'      => 'widget_title_color',
				'name'    => __( 'Widget Title Text Color', 'jumpstart' ),
				'desc'    => __( 'Select the text color for titles of widgets.', 'jumpstart' ),
				'std'     => '#333333',
				'type'    => 'color',
				'class'   => 'hide receiver receiver-standard receiver-panel',
			),
			'widget_title_size' => array(
				'id'      => 'widget_title_size',
				'name'    => __( 'Widget Title Text Size', 'jumpstart' ),
				'desc'    => __( 'Select the text size for titles of widgets.', 'jumpstart' ),
				'std'     => '18px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '10',
					'max'   => '30',
				),
				'class'   => 'hide receiver receiver-standard receiver-panel',
			),
			'widget_title_shadow' => array(
				'id'      => 'widget_title_shadow',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Widget Title Text Shadow', 'jumpstart' ) . '</strong>: ' . __( 'Apply shadow to widget title text.', 'jumpstart' ),
				'std'     => 0,
				'type'    => 'checkbox',
				'class'   => 'hide receiver receiver-standard receiver-panel',
			),
			'sub_group_start_15' => array(
				'id'      => 'sub_group_start_15',
				'type'    => 'subgroup_start',
				'class'   => 'show-hide hide receiver receiver-standard',
			),
			'widget_apply_border' => array(
				'id'      => 'widget_apply_border',
				'name'    => null,
				'desc'    => '<strong>' . __( 'Widget Border', 'jumpstart' ) . '</strong>: ' . __( 'Apply border around widgets.', 'jumpstart' ),
				'std'     => 0,
				'type'    => 'checkbox',
				'class'   => 'trigger',
			),
			'widget_border_color' => array(
				'id'      => 'widget_border_color',
				'name'    => __( 'Border Color', 'jumpstart' ),
				'desc'    => __( 'Select a color for the border.', 'jumpstart' ),
				'std'     => '#f2f2f2',
				'type'    => 'color',
				'class'   => 'hide receiver',
			),
			'widget_border_width' => array(
				'id'      => 'widget_border_width',
				'name'    => __( 'Border Width', 'jumpstart' ),
				'desc'    => __( 'Select a width in pixels for the border.', 'jumpstart' ),
				'std'     => '1px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '1',
					'max'   => '10',
				),
				'class'   => 'hide receiver',
			),
			'sub_group_end_15' => array(
				'id'      => 'sub_group_end_15',
				'type'    => 'subgroup_end',
			),
			'sub_group_end_13' => array(
				'id'      => 'sub_group_end_13',
				'type'    => 'subgroup_end',
			),
		),
		'extras' => array(
			'highlight' => array(
				'id'      => 'highlight',
				'name'    => __( 'Highlight Color', 'jumpstart' ),
				'desc'    => __( 'Select a Highlight color to be used in a few little areas throughout your site.', 'jumpstart' ),
				'std'     => '#fec527',
				'type'    => 'color',
			),
			'box_titles' => array(
				'id'      => 'box_titles',
				'name'    => null,
				'desc'    => __( 'Display special styling to titles of info boxes and standard widgets.', 'jumpstart' ),
				'std'     => '1',
				'type'    => 'checkbox',
			),
			'thumbnail_circles' => array(
				'id'      => 'thumbnail_circles',
				'name'    => null,
				'desc'    => __( 'Display avatars and small featured images as circles', 'jumpstart' ),
				'std'     => '1',
				'type'    => 'checkbox',
			),
		),
		'css' => array(
			'custom_styles' => array(
				'id'       => 'custom_styles',
				'name'     => null,
				'desc'     => null,
				'std'      => '',
				'type'     => 'code',
				'lang'     => 'css',
			),
		),
	));

	themeblvd_add_option_tab( 'styles', __( 'Styles', 'jumpstart' ), true );

	// translators: 1: link to Theme Base admin page
	themeblvd_add_option_section( 'styles', 'presets', __( 'Preset Styles', 'jumpstart' ), __( 'For a quick starting point, click any image below to merge its preset settings into your current option selections. Then, you can continue editing individual options.', 'jumpstart' ) . ' &mdash; ' . sprintf( __( 'Looking for more theme style variations? Try a different %s.', 'jumpstart' ), '<a href="themes.php?page=jumpstart-base" target="_blank">Theme Base</a>' ), array() );

	if ( is_admin() ) {

		themeblvd_add_option_presets( jumpstart_ent_get_presets() );

	}

	themeblvd_add_option_section( 'styles', 'ent_general',       __( 'General', 'jumpstart' ),         null, $options['general'] );

	themeblvd_add_option_section( 'styles', 'ent_header_info',   __( 'Header Info', 'jumpstart' ),     null, $options['header_info'] );

	themeblvd_add_option_section( 'styles', 'ent_header',        __( 'Header', 'jumpstart' ),          null, $options['header'] );

	themeblvd_add_option_section( 'styles', 'ent_header_mobile', __( 'Mobile Header', 'jumpstart' ),   null, $options['header_mobile'] );

	themeblvd_add_option_section( 'styles', 'ent_menu',          __( 'Main Menu', 'jumpstart' ),       null, $options['menu'] );

	themeblvd_add_option_section( 'styles', 'ent_menu_mobile',   __( 'Mobile Menu', 'jumpstart' ),     null, $options['menu_mobile'] );

	themeblvd_add_option_section( 'styles', 'ent_side_panel',    __( 'Side Panel', 'jumpstart' ),      null, $options['side_panel'] );

	themeblvd_add_option_section( 'styles', 'ent_footer',        __( 'Footer', 'jumpstart' ),          null, $options['footer'] );

	themeblvd_add_option_section( 'styles', 'ent_typo',          __( 'Typography', 'jumpstart' ),      null, $options['typo'] );

	themeblvd_add_option_section( 'styles', 'ent_buttons',       __( 'Buttons', 'jumpstart' ),         null, $options['buttons'] );

	themeblvd_add_option_section( 'styles', 'ent_widgets',       __( 'Sidebar Widgets', 'jumpstart' ), null, $options['widgets'] );

	themeblvd_add_option_section( 'styles', 'ent_extras',        __( 'Extras', 'jumpstart' ),          null, $options['extras'] );

	themeblvd_add_option_section( 'styles', 'ent_css',           __( 'Custom CSS', 'jumpstart' ),      null, $options['css'] );

	themeblvd_edit_option( 'layout', 'header', 'logo', 'std', array(
		'type'         => 'image',
		'image'        => get_template_directory_uri() . '/assets/img/logo-small.png',
		'image_width'  => '165',
		'image_height' => '50',
		'image_2x'     => get_template_directory_uri() . '/assets/img/logo-small_2x.png',
	));

	themeblvd_edit_option( 'layout', 'header_trans', 'trans_logo', 'std', array(
		'type'         => 'image',
		'image'        => get_template_directory_uri() . '/assets/img/logo-small-light.png',
		'image_width'  => '165',
		'image_height' => '50',
		'image_2x'     => get_template_directory_uri() . '/assets/img/logo-small-light_2x.png',
	));

}
add_action( 'after_setup_theme', 'jumpstart_ent_options' );
