<?php
/**
 * Theme-Specific Functions
 *
 * This file is included immediately after framework
 * runs and serves as basis for all theme-specific
 * modifications.
 *
 * All theme-specific functionality should be included
 * in the theme's root `inc` directory. And any files
 * in there besides this one should be included from
 * this file.
 *
 * @author    Jason Bobich <info@themeblvd.com>
 * @copyright 2009-2017 Theme Blvd
 * @package   Jump_Start
 * @since     Jump_Start 2.0.0
 */

/**
 * Include in-dashboard update system.
 */
include_once( get_template_directory() . '/inc/theme-updates.php' );

/**
 * Global configuration, enable theme bases.
 *
 * @since Jump_Start 2.0.0
 *
 * @param  array $config Configuration settings from framework.
 * @return array $config Modified configuration settings.
 */
function jumpstart_global_config( $config ) {

	$config['admin']['base'] = true;

	return $config;

}
add_filter( 'themeblvd_global_config', 'jumpstart_global_config' );

/**
 * Setup theme bases admin.
 *
 * @since Jump_Start 2.0.0
 */
function jumpstart_bases() {

	if ( is_admin() && themeblvd_supports( 'admin', 'base' ) ) {

		/**
		 * Filter theme bases added by Jump Start, which
		 * are passed to the object created with
		 * class Theme_Blvd_Bases.
		 *
		 * @since Jump_Start 2.0.0
		 *
		 * @param array Theme bases being added.
		 */
		$bases = apply_filters( 'themeblvd_bases', array(
			'dev' => array(
				'name' => __( 'Developer', 'jumpstart' ),
				'desc' => __( 'If you\'re a developer looking to create a custom-designed child theme, this is the base for you.', 'jumpstart' ),
			),
			'superuser' => array(
				'name' => __( 'Super User', 'jumpstart' ),
				'desc' => __( 'For the super user, this base builds on the default theme to give you more visual, user options.', 'jumpstart' ),
			),
			'agent' => array(
				'name' => __( 'Agent', 'jumpstart' ),
				'desc' => __( 'A modern and open, agency-style design with a bit less user options.', 'jumpstart' ),
			),
			'entrepreneur' => array(
				'name' => __( 'Entrepreneur', 'jumpstart' ),
				'desc' => __( 'A more standard, corporate design with a lot of user options.', 'jumpstart' ),
			),
			'executive' => array(
				'name' => __( 'Executive', 'jumpstart' ),
				'desc' => __( 'A more classic, corporate design with a lot of user options.', 'jumpstart' ),
			),
		));

		$admin = new Theme_Blvd_Bases( $bases, themeblvd_get_default_base() ); // Class included with is_admin().

	}

}
add_action( 'after_setup_theme', 'jumpstart_bases' );

/*
 * Include theme base.
 */
$base = themeblvd_get_base();

if ( $base ) {

	include_once( themeblvd_get_base_path( $base ) . '/base.php' );

}

/**
 * Enqueue Jump Start CSS files.
 *
 * @since 1.0.0
 */
function jumpstart_css() {

	$suffix = SCRIPT_DEBUG ? '' : '.min';

	$theme = wp_get_theme( get_template() );

	$ver = $theme->get( 'Version' );

	$stylesheet_ver = $ver;

	if ( get_template() !== get_stylesheet() ) {

		$theme = wp_get_theme( get_stylesheet() );

		$stylesheet_ver = $theme->get( 'Version' );

	}

	/*
	 * Theme Stylesheet
	 */
	if ( is_rtl() ) {

		wp_enqueue_style(
			'jumpstart',
			esc_url( get_template_directory_uri() . "/assets/css/theme-rtl{$suffix}.css" ),
			array( 'themeblvd' ),
			$ver
		);

	} else {

		wp_enqueue_style(
			'jumpstart',
			esc_url( get_template_directory_uri() . "/assets/css/theme{$suffix}.css" ),
			array( 'themeblvd' ),
			$ver
		);

	}

	/*
	 * Theme Base Stylesheet
	 */
	$base = themeblvd_get_base();

	if ( $base && 'dev' !== $base ) {

		wp_enqueue_style(
			'jumpstart-base',
			esc_url( themeblvd_get_base_uri( $base ) . "/base{$suffix}.css" ),
			array( 'themeblvd' ),
			$ver
		);

	}

	/*
	 * IE Stylesheet
	 */
	wp_enqueue_style(
		'themeblvd-ie',
		esc_url( get_template_directory_uri() . '/assets/css/ie.css' ),
		array(),
		$ver
	);

	$GLOBALS['wp_styles']->add_data( 'themeblvd-ie', 'conditional', 'IE' );

	/*
	 * Primary style.css
	 */
	wp_enqueue_style(
		'themeblvd-theme',
		esc_url( get_stylesheet_uri() ),
		array( 'themeblvd' ),
		$stylesheet_ver
	);

}
add_action( 'wp_enqueue_scripts', 'jumpstart_css', 20 );

/**
 * Jump Start base check.
 *
 * If WP user is logged in, output message on frontend
 * to tell them their saved theme options don't match
 * the theme base they've selected.
 *
 * @since Jump_Start 2.0.0
 */
function jumpstart_base_check() {

	if ( ! is_user_logged_in() ) {

		return;

	}

	if ( ! themeblvd_supports( 'admin', 'base' ) ) {

		return;

	}

	if ( themeblvd_get_option( 'theme_base' ) == themeblvd_get_base() ) {

		return; // All good!

	}

	themeblvd_alert(
		array(
			'style' => 'warning',
			'class' => 'full',
		),
		__( 'Warning: Your saved theme options do not currently match the theme base you\'ve selected. Please configure and save your theme options page.', 'jumpstart' )
	);

}
add_action( 'themeblvd_before', 'jumpstart_base_check' );

/**
 * Get re-useable option sets for theme bases.
 *
 * As theme bases have grown, many options have become
 * fairly consistent across multiple theme bases. So
 * this function can help to eliminate a lot of duplicate
 * code that has crept up.
 *
 * Note: For the `typography` set options, the theme base
 * must pass in the $defaults.
 *
 * @since Jump_Start 2.2.0
 *
 * @param  string $set      Type of option set, like `typography`, `buttons`, `widgets`, etc.
 * @param  array  $defaults Any custom default values.
 * @return array  $options  Options set.
 */
function jumpstart_get_shared_options( $set, $defaults = array() ) {

	$options = array();

	switch ( $set ) {

		/*
		 * Set up mobile header options.
		 */
		case 'mobile-header':
			$options['header_mobile_info'] = array(
				'id'   => 'header_mobile_info',
				'desc' => __( 'These styles are applied to your header across most mobile devices and portrait tablets.', 'jumpstart' ),
				'type' => 'info',
			);

			$options['header_mobile_bg_color'] = array(
				'id'   => 'header_mobile_bg_color',
				'name' => __( 'Background Color', 'jumpstart' ),
				'desc' => __( 'Select a background color for the mobile header.', 'jumpstart' ),
				'std'  => '#101010',
				'type' => 'color',
			);

			$options['header_mobile_bg_color_brightness'] = array(
				'id'      => 'header_mobile_bg_color_brightness',
				'name'    => __( 'Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'std'     => 'dark',
				'type' 	  => 'select',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark' 	=> __( 'I chose a dark color in the previous option.', 'jumpstart' )
				),
			);

			$options['header_mobile_icon_color'] = array(
				'id'   => 'header_mobile_icon_color',
				'name' => __( 'Icon Color', 'jumpstart' ),
				'desc' => __( 'Select a color for the navigational icons in the mobile header.', 'jumpstart' ),
				'std'  => '#ffffff',
				'type' => 'color',
			);

			$options['header_mobile_height'] = array(
				'id'      => 'header_mobile_height',
				'name'    => __( 'Height', 'jumpstart' ),
				'desc'    => __( 'Set the height of your mobile header in pixels. This number should be higher than the height of your mobile logo image at <em>Layout > Mobile Header</em>.', 'jumpstart' ),
				'std'     => '64px',
				'type'    => 'slide',
				'options' => array(
					'min'   => '40',
					'max'   => '150',
					'step'  => '1',
					'units' => 'px',
				)
			);

			break;

		/*
		 * Set up typography options.
		 *
		 * Note: Theme bases should pass in $defaults for typography
		 * options which include values for the following:
		 *
		 * 1. font_body
		 * 2. font_header
		 * 3. font_header_sm
		 * 4. font_header_sm_sp
		 * 5. font_meta
		 * 6. font_meta_sp
		 * 7. font_menu
		 * 8. font_menu_sp
		 */
		case 'typography':
			$options['font_body'] = array(
				'id'   => 'font_body',
				'name' => __( 'Primary Font', 'jumpstart' ),
				'desc' => __( 'This applies to most of the text on your site.', 'jumpstart' ),
				'std'  => array(),
				'atts' => array( 'size', 'face', 'style', 'weight' ),
				'type' => 'typography',
			);

			$options['font_header'] = array(
				'id'   => 'font_header',
				'name' => __( 'Header Font', 'jumpstart' ),
				'desc' => __( 'This applies to all of the primary headers throughout your site (h1, h2, h3, h4, h5, h6). This would include header tags used in redundant areas like widgets and the content of posts and pages.', 'jumpstart' ),
				'std'  => array(),
				'atts' => array( 'face', 'style', 'weight' ),
				'type' => 'typography',
			);

			$options['font_header_sm'] = array(
				'id'   => 'font_header_sm',
				'name' => __( 'Small Header Font', 'jumpstart' ),
				'desc' => __( 'This applies to smaller sub headers throughout your website, like widget titles, for example.', 'jumpstart' ),
				'std'  => array(),
				'atts' => array( 'face', 'style', 'weight' ),
				'type' => 'typography',
			);

			$options['font_header_sm_sp'] = array(
				'id'      => 'font_header_sm_sp',
				'name'    => __( 'Small Header Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			);

			$options['font_quote'] = array(
				'id'   => 'font_quote',
				'name' => __( 'Quote Font', 'jumpstart' ),
				'desc' => __( 'This applies to quoted text in blockquote tags.', 'jumpstart' ),
				'std'  => array(
					'size'   => '',
					'face'   => 'google',
					'weight' => '400',
					'color'  => '',
					'google' => 'Libre Baskerville:400italic',
					'style'  => 'italic',
				),
				'atts' => array( 'face', 'style', 'weight' ),
				'type' => 'typography',
			);

			$options['font_quote_sp'] = array(
				'id'      => 'font_quote_sp',
				'name'    => __( 'Quote Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			);

			$options['font_meta'] = array(
				'id'   => 'font_meta',
				'name' => __( 'Meta Info Font', 'jumpstart' ),
				'desc' => __( 'This applies to meta info like the "Posted" date below a post title, for example.', 'jumpstart' ),
				'std'  => array(),
				'atts' => array( 'face', 'style', 'weight' ),
				'type' => 'typography',
			);

			$options['font_meta_sp'] = array(
				'id'      => 'font_meta_sp',
				'name'    => __( 'Meta Info Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			);

			$options['font_epic'] = array(
				'id'   => 'font_epic',
				'name' => __( 'Featured Image Title Font', 'jumpstart' ),
				'desc' => __( 'This applies when displaying a title on top of featured images.', 'jumpstart' ),
				'std'  => array(
					'size'   => '50px',
					'face'   => 'google',
					'weight' => '700',
					'color'  => '',
					'google' => 'Montserrat:700',
					'style'  => 'uppercase',
				),
				'atts'  => array( 'face', 'style', 'weight', 'size' ),
				'sizes' => array( '25', '26', '150' ),
				'type'  => 'typography',
			);

			$options['font_epic_sp'] = array(
				'id'      => 'font_epic_sp',
				'name'    => __( 'Featured Image Title Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '3px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			);

			$options['font_menu'] = array(
				'id'    => 'font_menu',
				'name'  => __( 'Main Menu Font', 'jumpstart' ),
				'desc'  => __( 'This font applies to the top level items of the main menu.', 'jumpstart' ),
				'std'   => array(),
				'atts'  => array( 'size', 'face', 'style', 'weight' ),
				'type'  => 'typography',
				'sizes' => array( '10', '11', '12', '13', '14', '15', '16', '17', '18' ),
			);

			$options['font_menu_sp'] = array(
				'id'      => 'font_menu_sp',
				'name'    => __( 'Main Menu Letter Spacing', 'jumpstart' ),
				'desc'    => __( 'Adjust the spacing between letters.', 'jumpstart' ),
				'std'     => '0px',
				'type'    => 'slide',
				'options' => array(
					'units' => 'px',
					'min'   => '0',
					'max'   => '5',
					'step'  => '1',
				),
			);

			$options['link_color'] = array(
				'id'   => 'link_color',
				'name' => __( 'Link Color', 'jumpstart' ),
				'desc' => __( 'Choose the color you\'d like applied to links.', 'jumpstart' ),
				'std'  => '#2ea3f2',
				'type' => 'color',
			);

			$options['link_hover_color'] = array(
				'id'   => 'link_hover_color',
				'name' => __( 'Link Hover Color', 'jumpstart' ),
				'desc' => __( 'Choose the color you\'d like applied to links when they are hovered over.', 'jumpstart' ),
				'std'  => '#337ab7',
				'type' => 'color',
			);

			$options['footer_link_color'] = array(
				'id'   => 'footer_link_color',
				'name' => __( 'Footer Link Color', 'jumpstart' ),
				'desc' => __( 'Choose the color you\'d like applied to links in the footer.', 'jumpstart' ),
				'std'  => '#2ea3f2',
				'type' => 'color',
			);

			$options['footer_link_hover_color'] = array(
				'id'   => 'footer_link_hover_color',
				'name' => __( 'Footer Link Hover Color', 'jumpstart' ),
				'desc' => __( 'Choose the color you\'d like applied to links in the footer when they are hovered over.', 'jumpstart' ),
				'std'  => '#337ab7',
				'type' => 'color',
			);

			break;

		/*
		 * Set up options for buttons.
		 */
		case 'buttons':
			// ...
			break;

		/*
		 * Set up options for sidebar widgets.
		 */
		case 'widgets':
			// @TODO Issue #265
			// @link https://github.com/themeblvd/jumpstart/issues/265
			break;

		/*
		 * Set up options for the site footer.
		 */
		case 'footer':
			$options['footer_info'] = array(
				'id'   => 'footer_info',
				// translators: 1: link to WP Menus admin page
				'desc' => sprintf( __( 'These options apply to the footer of your website. Note that for the footer menu to show in the copyright area, you must assign a menu to the "Footer Navigation" location at %s.', 'jumpstart' ), '<a href="nav-menus.php" target="_blank">' . __( 'Appearance > Menus', 'jumpstart' ) . '</a>' ),
				'type' => 'info',
			);

			$options['footer_bg_start'] = array(
				'id'    => 'footer_bg_start',
				'type'  => 'subgroup_start',
				'class' => 'show-hide-toggle',
			);

			$options['footer_bg_type'] = array(
				'id'      => 'footer_bg_type',
				'name'    => __( 'Apply Footer Background', 'jumpstart' ),
				// translators: 1: location of where to setup Footer features on Theme Options screen
				'desc'    => __( 'Select if you\'d like to apply a custom background color to the footer.', 'jumpstart' ) . '<br><br>' . sprintf( __( 'Note: To setup a more complex designed footer, go to %s and use the "Template Sync" feature.', 'jumpstart' ), '<em>' . __( 'Layout > Footer', 'jumpstart' ) . '</em>' ),
				'std'     => 'color',
				'type'    => 'select',
				'options' => array(
					'none'    => __( 'None', 'jumpstart' ),
					'color'   => __( 'Custom color', 'jumpstart' ),
					'texture' => __( 'Custom color + texture', 'jumpstart' ),
				),
				'class'   => 'trigger',
			);

			$options['footer_bg_texture'] = array(
				'id'     => 'footer_bg_texture',
				'name'   => __( 'Background Texture', 'jumpstart' ),
				'desc'   => __( 'Select a background texture.', 'jumpstart' ),
				'type'   => 'select',
				'select' => 'textures',
				'class'  => 'hide receiver receiver-texture',
			);

			$options['footer_bg_color'] = array(
				'id'   => 'footer_bg_color',
				'name' => __( 'Footer Background Color', 'jumpstart' ),
				'desc' => __( 'Select a background color for the footer columns.', 'jumpstart' ),
				'std'  => '#222222',
				'type' => 'color',
			);

			$options['footer_bg_color_brightness'] = array(
				'id'      => 'footer_bg_color_brightness',
				'name'    => __( 'Footer Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'In the previous option, did you go dark or light?', 'jumpstart' ),
				'std'     => 'dark',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
			);

			$options['footer_bg_color_opacity'] = array(
				'id'        => 'footer_bg_color_opacity',
				'name'      => __( 'Background Color Opacity', 'jumpstart' ),
				'desc'      => __( 'Select the opacity of the background color you chose.', 'jumpstart' ),
				'std'       => '1',
				'type'      => 'select',
				'options'   => array(
					'0.05'  => '5%',
					'0.1'   => '10%',
					'0.15'  => '15%',
					'0.2'   => '20%',
					'0.25'  => '25%',
					'0.3'   => '30%',
					'0.35'  => '35%',
					'0.4'   => '40%',
					'0.45'  => '45%',
					'0.5'   => '50%',
					'0.55'  => '55%',
					'0.6'   => '60%',
					'0.65'  => '65%',
					'0.7'   => '70%',
					'0.75'  => '75%',
					'0.8'   => '80%',
					'0.85'  => '85%',
					'0.9'   => '90%',
					'0.95'  => '95%',
					'1'     => '100%',
				),
				'class'     => 'hide receiver receiver-color receiver-texture',
			);

			$options['footer_bg_start'] = array(
				'id'   => 'footer_bg_start',
				'type' => 'subgroup_end',
			);

			$options['copyright_bg_color'] = array(
				'id'   => 'copyright_bg_color',
				'name' => __( 'Copyright Background Color', 'jumpstart' ),
				'desc' => __( 'Select a background color for the copyright area below the footer columns.', 'jumpstart' ),
				'std'  => '#1b1b1b',
				'type' => 'color',
			);

			$options['copyright_bg_color_brightness'] = array(
				'id'      => 'copyright_bg_color_brightness',
				'name'    => __( 'Copyright Background Color Brightness', 'jumpstart' ),
				'desc'    => __( 'If you\'re using a dark background color, select to show light text, and vice versa.', 'jumpstart' ),
				'std'     => 'dark',
				'type'    => 'radio',
				'options' => array(
					'light' => __( 'I chose a light color in the previous option.', 'jumpstart' ),
					'dark'  => __( 'I chose a dark color in the previous option.', 'jumpstart' ),
				),
			);

			break;

		/*
		 * Set up options for Front Street branding
		 * colors.
		 */
		case 'branding':
			// @TODO Issue #264
			// @link https://github.com/themeblvd/jumpstart/issues/264


	}

	if ( $defaults && $options ) {

		foreach ( $options as $option_id => $option ) {

			if ( isset( $defaults[ $option_id ] ) ) {

				$options[ $option_id ]['std'] = $defaults[ $option_id ];

			}
		}

	}

	return $options;

}

/**
 * Add Jump Start Homepage to sample layouts of
 * Layout Builder plugin.
 *
 * @since Jump_Start 2.0.0
 *
 * @param  array $layouts All sample layouts.
 * @return array $layouts Modified sample layouts.
 */
function jumpstart_sample_layouts( $layouts ) {

	$layouts['jumpstart-home'] = array(
		'name'   => __( 'Jump Start: Home', 'jumpstart' ),
		'id'     => 'jumpstart-home',
		'dir'    => get_template_directory() . '/inc/layouts/home/',
		'uri'    => get_template_directory_uri() . '/inc/layouts/home/',
		'assets' => get_template_directory_uri() . '/inc/layouts/home/img/',
	);

	return $layouts;

}
add_filter( 'themeblvd_sample_layouts', 'jumpstart_sample_layouts' );
